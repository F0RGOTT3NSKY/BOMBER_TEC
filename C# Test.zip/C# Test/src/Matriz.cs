using System;

namespace scr
{
    public class Matriz
    {
        public int NFilas_Map;

        public int NColumnas_Map;

        public float[,] map;

        public Matriz(int _nFila, int _nColumna)
        {
            this.NFilas_Map = _nFila;
            this.NColumnas_Map = _nColumna;
            this.map = randomMap(NFilas_Map, NColumnas_Map);
        }

    public float[,] randomMap(int filas, int columnas)
    {
        float[,] _map = new float[filas, columnas];

        System.Random randomBlock = new System.Random();

        int NFilas = _map.GetLength(0);
        int NColumnas = _map.GetLength(1);

        int Filas = NFilas - 1;
        int Columnas = NColumnas - 1;

        for (int i = 0; i < NFilas; i ++)
        {
            for (int j = 0; j < NColumnas; j++)
            {
                // Crear el marco derecho e iquierdo del mapa
                if (j == 0 || j == Columnas)
                {
                    _map[i, j] = 2f;
                }
                // Crea el marco superior e inferior del mapa
                else if (i == 0 || i == Filas)
                {
                   _map[i, j] = 2f;
                }
                // Crea el interior del mapa
                else
                {
                    float num = randomBlock.Next(1,4);
                    if (num ==2f)
                    {
                        _map[i, j] = num;
                    }else{
                        _map[i, j] = 0f;
                    }
                }
            }
        }
        _map[1,1] = 7f;
        _map[5,5] = 9f;
        return _map; 
    }

        public void printMatriz()
        {

            for (int i = 0; i < NFilas_Map; i++)
            {
                for (int j = 0; j < NColumnas_Map; j++)
                {
                    Console.Write(this.map[i, j] + " - ");
                }
                Console.Write("\n");
            }
        }
    }
}