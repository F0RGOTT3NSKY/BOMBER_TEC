﻿using System;

namespace scr
{
    class Program
    {
        static void Main(string[] args)
        {
            //Aqui esta la lista simple para PRUEBAS
            /*
            ListaSimple lista = new ListaSimple();
            Dato nodoTest = new Dato(0,0);
            lista.enqueue(nodoTest);
            lista.printLista();
            
            nodoTest = new Dato(0,1);
            lista.enqueue(nodoTest);
            lista.printLista();

            lista.dequeue();
            lista.printLista();
            */

            //Aqui esta la matriz para PRUEBAS
            
            int grid = 7;
            Matriz mapa = new Matriz(grid, grid);
            mapa.printMatriz();
            

            //Aqui esta el A* para PRUEBAS
            //*
            AStar path = new AStar(10);

            int[] inicio = {1,1};
            int[] meta = {5,5};
            bool camino = path.findPath(mapa, inicio, meta);

            if(camino)
            {
                path.printSol();
            }else
            {
                Console.WriteLine("No habia camino");
            }
            mapa.printMatriz();
            //*/
        }
    }
}